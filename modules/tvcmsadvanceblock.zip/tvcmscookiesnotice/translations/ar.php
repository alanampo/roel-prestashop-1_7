<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{tvcmscookiesnotice}prestashop>display_home_1a9bf41c457d79d50e35dcfadafbd966'] = 'قبول الكل';
