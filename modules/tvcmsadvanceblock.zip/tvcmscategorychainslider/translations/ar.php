<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{tvcmscategorychainslider}prestashop>display_home_d8d7ad6abfd08c27baa8bedb78c72ddb'] = 'مشاهدة الكل';
