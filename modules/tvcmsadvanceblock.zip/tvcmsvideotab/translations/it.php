<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{tvcmsvideotab}prestashop>videotabhook_e60ae31f67ab883c746bb71c7a145c18'] = 'VIDEO';
