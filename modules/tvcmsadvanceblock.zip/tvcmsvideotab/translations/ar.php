<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{tvcmsvideotab}prestashop>popupvideo_990fb3d52538d66a5ae1e2a835599142'] = 'فيديو مباشر';
