<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{tvcmscategoryslider}prestashop>display_home_0a18f0aa51f30f1107495bf639caf16c'] = 'تسوق الآن';
