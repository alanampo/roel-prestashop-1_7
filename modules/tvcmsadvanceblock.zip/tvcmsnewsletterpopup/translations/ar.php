<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{tvcmsnewsletterpopup}prestashop>tvcmsnewsletterpopup_c0702b61402d0955a4cfe861efb13c54'] = 'أعلى تصنيفإدخال البريد الخاص بك ... ذ...';
$_MODULE['<{tvcmsnewsletterpopup}prestashop>tvcmsnewsletterpopup_b26917587d98330d93f87808fc9d7267'] = 'الإشتراك!';
$_MODULE['<{tvcmsnewsletterpopup}prestashop>tvcmsnewsletterpopup_a87408b0f38547f2a6eefaca4049b18f'] = 'لا تظهر هذه المنبثقة مرة أخرى';
