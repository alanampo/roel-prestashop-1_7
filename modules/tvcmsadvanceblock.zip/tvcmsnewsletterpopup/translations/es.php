<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{tvcmsnewsletterpopup}prestashop>tvcmsnewsletterpopup_c0702b61402d0955a4cfe861efb13c54'] = 'Ingrese su correo ...';
$_MODULE['<{tvcmsnewsletterpopup}prestashop>tvcmsnewsletterpopup_b26917587d98330d93f87808fc9d7267'] = 'Suscribir!';
$_MODULE['<{tvcmsnewsletterpopup}prestashop>tvcmsnewsletterpopup_a87408b0f38547f2a6eefaca4049b18f'] = 'No mostrar esta ventana emergente de nuevo';
